package Renata.Urbinati.LojaNoivas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaNoivasApplicationTests {

	@Test
	void contextLoads() {
	}

}
